const mongooseConnect = require('./connect');
const mongoose = require('mongoose');
//const userSchema = require('./schema');

(async () => {
  await mongooseConnect();

  const schema = mongoose.Schema({
    _id: String,
    appId: String,
    uid: String,
    fcmTokens: Object,
    settings: Object,
  });

  const gSchema = mongoose.Schema({
    _id: String,
    appIdGuid: String,
    appIdUid: String,
    guid: String,
    uid: String,
  });
  const userSchema = mongoose.model('user', schema);
  const groupSchema = mongoose.model('group', gSchema);
  console.log(process.argv);
  if (process.argv[2] == 'createUser') {
    let appId = process.argv[3];
    let userId = process.argv[4];

    console.time('createUser');
    const user = new userSchema({
      _id: appId + '_' + userId,
      appId: appId,
      uid: userId,
      fcmTokens: {
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00001: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00001-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00001-android',
          'android',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00002: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00002-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00002-ios',
          'ios',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00003: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00003-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00003-react_native',
          'react_native',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00004: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00004-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00004-ionic',
          'ionic',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00005: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00005-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00005-web',
          'web',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00006: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00006-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00006-android',
          'android',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00007: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00007-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00007-ios',
          'ios',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00008: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00008-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00008-react_native',
          'react_native',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00009: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00009-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00009-ionic',
          'ionic',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00010: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00010-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00010-web',
          'web',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00011: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00011-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00011-android',
          'android',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00012: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00012-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00012-ios',
          'ios',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00013: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00013-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00013-react_native',
          'react_native',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00014: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00014-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00014-ionic',
          'ionic',
        ],
        USERuvwxyz00001_AUTH16633494948085a924b216f77ec04d0be2ba5a2e00015: [
          'APPabcdefg00001-USERuvwxyz00001-AUTH16633494948085a924b216f77ec04d0be2ba5a2e00015-PUSH16633494948085a924b216f77ec04d0be2ba5a2e00015-web',
          'web',
        ],
      },
      settings: {
        chat: {
          muted_guids: {
            GROUPghijkl00002: "Long('1667030211282')",
            GROUPghijkl00001: "Long('1667030211282')",
            GROUPghijkl00003: "Long('1667030211282')",
            GROUPghijkl00004: "Long('1667030211282')",
            GROUPghijkl00005: "Long('1667030211282')",
            GROUPghijkl00006: "Long('1111111111111')",
            GROUPghijkl00007: "Long('1111111111111')",
            GROUPghijkl00008: "Long('1111111111111')",
            GROUPghijkl00009: "Long('1111111111111')",
          },
        },
        call: {
          muted_guids: {
            GROUPghijkl00001: "Long('1667030211282')",
            GROUPghijkl00002: "Long('1667030211282')",
            GROUPghijkl00003: "Long('1667030211282')",
            GROUPghijkl00004: "Long('1667030211282')",
            GROUPghijkl00005: "Long('1667030211282')",
            GROUPghijkl00006: "Long('1667030211282')",
            GROUPghijkl00007: "Long('1667030211282')",
            GROUPghijkl00008: "Long('1667030211282')",
            GROUPghijkl00009: "Long('1111111111111')",
          },
        },
      },
    });
    await user.save();
    console.timeEnd('createUser');
  } else if (process.argv[2] == 'deleteUser') {
    let appID = process.argv[3],
      uid = process.argv[4];
    //`APPabcdefg00001 USERuvwxyz00002`
    console.time('deleteUser');
    await groupSchema.deleteMany({
      appIdUid: `${appID}_${uid}`,
    });
    await userSchema.deleteOne({
      _id: `${appID}_${uid}`,
    });
    console.timeEnd('deleteUser');
  } else if (process.argv[2] == 'addMemberToGroup') {
    const arr = [];
    let gArray = [
      'GROUPghijkl00001',
      'GROUPghijkl00002',
      'GROUPghijkl00003',
      'GROUPghijkl00004',
      'GROUPghijkl00005',
      'GROUPghijkl00006',
      'GROUPghijkl00007',
      'GROUPghijkl00008',
      'GROUPghijkl00009',
      'GROUPghijkl00010',
      'GROUPghijkl00011',
    ];
    console.time('addMemberToGroup');
    for (let i = 1; i < 101; i++) {
      if (i < 10) {
        i = `00${i}`;
      }
      if (i > 9 && i < 99) {
        i = `0${i}`;
      } else {
        i = `${i}`;
      }

      let random = Math.floor(Math.random() * 10);
      let obj = {
        _id: `APPabcdefg00100_${gArray[random]}_USERuvwxyz00${i}`,
        appIdGuid: `APPabcdefg00100_${gArray[random]}`,
        appIdUid: `APPabcdefg00100_USERuvwxyz00${i}`,
        guid: `${gArray[random]}`,
        uid: `USERuvwxyz00${i}`,
      };
      arr.push(obj);
    }
    const saveTogroup = await groupSchema.insertMany(arr);
    console.timeEnd('addMemberToGroup');
  } else if (process.argv[2] == 'deleteMemberFromGroup') {
    //     3. When users are removed/kicked from a group
    // Given: ['appId', 'uid[]', 'guid'],
    // Action:
    //     - Remove entries from the groups collection.
    //         - _id
    //     - Fetch the uids from the entries that were removed.
    //         - _id
    //     - Use the uids to query and remove the entries from user collection => settings.(chat/calls).muted_guids.guid
    //         - uid
    //     - Query users collection using the uid and send PN.
    //GROUPghijkl00002
    //node index.js deleteMemberFromGroup APPabcdefg00001 "USERuvwxyz00002,USERuvwxyz00003" "GROUPghijkl00001"
    //console.log(process.argv[4].split(','));
    //process.exit();
    // [
    //   {
    //     _id: 'APPabcdefg00001_GROUPghijkl00005_USERuvwxyz00002',
    //     appIdGuid: 'APPabcdefg00100_GROUPghijkl00022',
    //     appIdUid: 'APPabcdefg00100_USERuvwxyz00022',
    //     guid: 'GROUPghijkl00005',
    //     uid: 'USERuvwxyz00002',
    //   },
    //   {
    //     _id: 'APPabcdefg00001_GROUPghijkl00005_USERuvwxyz00003',
    //     appIdGuid: 'APPabcdefg00100_GROUPghijkl00005',
    //     appIdUid: 'APPabcdefg00100_USERuvwxyz00005',
    //     guid: 'GROUPghijkl00005',
    //     uid: 'USERuvwxyz00003',
    //   },
    // ]
    let appId = process.argv[3];
    let uid = process.argv[4].split(',');
    let guid = process.argv[5];
    let appUidArrays = uid.map((eachUid) => {
      return appId + '_' + eachUid;
    });

    let _idGroupArray = uid.map((eachUid) => {
      return appId + '_' + guid + '_' + eachUid;
    });
    console.time('deleteMemberFromGroup');
    const data = await userSchema.find({
      _id: {
        $in: appUidArrays,
      },
    });
    let updateArray = [];
    for (let i = 0; i < data.length; i++) {
      delete data[i].settings.chat.muted_guids[guid];
      delete data[i].settings.call.muted_guids[guid];
      updateArray.push({
        updateOne: {
          filter: { _id: appUidArrays[i] },
          update: {
            $set: {
              settings: data[i].settings,
            },
          },
        },
      });
    }
    await groupSchema.deleteMany({
      _id: {
        $in: _idGroupArray,
      },
    });

    await userSchema.bulkWrite(updateArray);
    console.timeEnd('deleteMemberFromGroup');

    //console.log(data);
  } else if (process.argv[2] == 'groupIsDeleted') {
    let appID = process.argv[3],
      guID = process.argv[4];
    // Find uid (appIdGuid)
    const findQuery = {
      appIdGuid: `${appID}_${guID}`,
    };
    const filter = { uid: 1, _id: 0 };
    console.log(findQuery);
    console.log(filter);
    console.time('groupIsDeleted');
    const user_ids = await groupSchema.find(findQuery, filter);
    await groupSchema.deleteMany({
      appIdGuid: `${appID}_${guID}`,
    });
    // command: node index groupIsDeleted APPabcdefg00100  GROUPghijkl00009
    for (let uid_obj of user_ids) {
      let updateQuery = {
        _id: `${appID}_${uid_obj.uid}`,
      };
      let updateFilter = {
        $unset: {
          [`settings.chat.muted_guids.${guID}`]: '',
          [`settings.call.muted_guids.${guID}`]: '',
        },
      };
      await userSchema.updateOne(updateQuery, updateFilter);
      //console.log(updateQuery);
      //console.log(updateFilter);
    }
    console.timeEnd('groupIsDeleted');
  } else if (process.argv[2] == 'messageSentInGroup') {
    console.time('messageSentInGroup');
    //  messageSent: ['appId', 'uid', 'guid'],
    //      appId=APPabcdefg00100
    //      guid=GROUPghijkl00001
    //    uid = USERuvwxyz00007
    let appIdUid = await groupSchema
      .find({
        $and: [
          {
            appIdGuid: 'APPabcdefg00100_GROUPghijkl00009',
          },
          { uid: { $ne: 'USERuvwxyz00001' } },
        ],
      })
      .select({ appIdUid: 1, _id: 0 });

    appIdUid = appIdUid.map((item) => item.appIdUid);

    const userData = await userSchema.find({ _id: { $in: appIdUid } });
    console.log(userData);
    console.timeEnd('messageSentInGroup');
  }
})();

// {
//   _id: 'APPabcdefg00100_GROUPghijkl00004_USERuvwxyz00002',
//   appIdGuid: 'APPabcdefg00100_GROUPghijkl00004',
//   appIdUid: 'APPabcdefg00100_USERuvwxyz00002',
//   guid: 'GROUPghijkl00004',
//   uid: 'USERuvwxyz00002',
//   __v: 0
// }
